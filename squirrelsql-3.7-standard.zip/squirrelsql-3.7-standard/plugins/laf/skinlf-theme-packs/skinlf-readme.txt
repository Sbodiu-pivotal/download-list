Drop Skin Look and Feel theme packs in here and restart Squirrel SQL Client.

See http://www.L2FProd.com for theme packs.